# SimpleModifyHeaders

Extension for firefox . 

The extension rewrite the headers based on a rules table. 

The rules table contains lines with the following parameters :
- action : add, modify or delete a header field
- header field name
- header field value 
- status : on if the modification is active , off otherwise 

We can choose the urls on which the modifications applies by modifying the url pattern.

To save and apply the modification , you need to click on the save button

The extension can be start and stop via the button on the top right.

The code is opensource under Mozilla Public License 2.0 




